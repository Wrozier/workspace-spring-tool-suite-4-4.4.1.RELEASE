package com.collabera.jump.ems;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collector;



public enum Department
{

	ACCOUNTING,	HR ,DEVELOPMENT , SALES

}

 


